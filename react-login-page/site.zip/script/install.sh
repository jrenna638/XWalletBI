#!/bin/bash
sudo yum install -y httpd